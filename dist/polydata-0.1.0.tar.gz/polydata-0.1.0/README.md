### Reading polygon data
## You must bring your own polygon.io api key

I have been using high frequency polygon data, and it is useful to have this script both for sectioning and for skipping holidays.

